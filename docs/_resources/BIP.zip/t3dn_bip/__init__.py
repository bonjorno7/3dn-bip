'''Load image previews in parallel and in any resolution. Supports BIP files.'''

__version__ = '0.0.9'
